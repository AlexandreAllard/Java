package fr.esgi.poo.java;

public class Launcher {
    public static void main(String[] args) {
        //Code de test Exercice1
        /*
            Exo1 litre = new Exo1(1);
            litre.convertTo();
            litre.display();
        */

        //Code de test Exercice2
        /*
            Exo2 array = new Exo2(2,5,1,6);
            array.min();
        */

    }
}
