package fr.esgi.poo.java;

public class Square {
    public int cote;

    public Square(int cote) {
        this.cote = cote;
    }

    public int Area() {
        return cote*cote;
    }

    public int Perimeter() {
        return (cote*4);
    }
}
